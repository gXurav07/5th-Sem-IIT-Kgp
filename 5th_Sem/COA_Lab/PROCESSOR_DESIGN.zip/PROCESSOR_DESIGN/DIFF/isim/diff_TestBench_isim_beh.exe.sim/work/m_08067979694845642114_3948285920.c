/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/gaurav/IIT_KGP_COURSES/5th_Sem/COA_Lab/PROCESSOR_DESIGN/DIFF/diff.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};



static void Always_29_0(char *t0)
{
    char t6[8];
    char t12[8];
    char t18[8];
    char t33[8];
    char t59[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t60;

LAB0:    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 3000);
    *((int *)t2) = 1;
    t3 = (t0 + 2712);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(30, ng0);

LAB5:    xsi_set_current_line(31, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    xsi_set_current_line(32, ng0);

LAB6:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1008U);
    t4 = (t2 + 72U);
    t5 = *((char **)t4);
    t7 = (t0 + 1768);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    xsi_vlog_generic_get_index_select_value(t6, 32, t3, t5, 2, t9, 32, 1);
    t10 = (t0 + 1208U);
    t11 = *((char **)t10);
    t10 = (t0 + 1168U);
    t13 = (t10 + 72U);
    t14 = *((char **)t13);
    t15 = (t0 + 1768);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    xsi_vlog_generic_get_index_select_value(t12, 32, t11, t14, 2, t17, 32, 1);
    t19 = *((unsigned int *)t6);
    t20 = *((unsigned int *)t12);
    t21 = (t19 ^ t20);
    *((unsigned int *)t18) = t21;
    t22 = (t6 + 4);
    t23 = (t12 + 4);
    t24 = (t18 + 4);
    t25 = *((unsigned int *)t22);
    t26 = *((unsigned int *)t23);
    t27 = (t25 | t26);
    *((unsigned int *)t24) = t27;
    t28 = *((unsigned int *)t24);
    t29 = (t28 != 0);
    if (t29 == 1)
        goto LAB7;

LAB8:
LAB9:    t32 = ((char*)((ng1)));
    memset(t33, 0, 8);
    t34 = (t18 + 4);
    t35 = (t32 + 4);
    t36 = *((unsigned int *)t18);
    t37 = *((unsigned int *)t32);
    t38 = (t36 ^ t37);
    t39 = *((unsigned int *)t34);
    t40 = *((unsigned int *)t35);
    t41 = (t39 ^ t40);
    t42 = (t38 | t41);
    t43 = *((unsigned int *)t34);
    t44 = *((unsigned int *)t35);
    t45 = (t43 | t44);
    t46 = (~(t45));
    t47 = (t42 & t46);
    if (t47 != 0)
        goto LAB13;

LAB10:    if (t45 != 0)
        goto LAB12;

LAB11:    *((unsigned int *)t33) = 1;

LAB13:    t49 = (t33 + 4);
    t50 = *((unsigned int *)t49);
    t51 = (~(t50));
    t52 = *((unsigned int *)t33);
    t53 = (t52 & t51);
    t54 = (t53 != 0);
    if (t54 > 0)
        goto LAB14;

LAB15:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1608);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 5);
    goto LAB2;

LAB7:    t30 = *((unsigned int *)t18);
    t31 = *((unsigned int *)t24);
    *((unsigned int *)t18) = (t30 | t31);
    goto LAB9;

LAB12:    t48 = (t33 + 4);
    *((unsigned int *)t33) = 1;
    *((unsigned int *)t48) = 1;
    goto LAB13;

LAB14:    xsi_set_current_line(33, ng0);

LAB16:    xsi_set_current_line(34, ng0);
    t55 = (t0 + 1768);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    t58 = ((char*)((ng2)));
    memset(t59, 0, 8);
    xsi_vlog_signed_add(t59, 32, t57, 32, t58, 32);
    t60 = (t0 + 1768);
    xsi_vlogvar_assign_value(t60, t59, 0, 0, 32);
    goto LAB6;

}


extern void work_m_08067979694845642114_3948285920_init()
{
	static char *pe[] = {(void *)Always_29_0};
	xsi_register_didat("work_m_08067979694845642114_3948285920", "isim/diff_TestBench_isim_beh.exe.sim/work/m_08067979694845642114_3948285920.didat");
	xsi_register_executes(pe);
}

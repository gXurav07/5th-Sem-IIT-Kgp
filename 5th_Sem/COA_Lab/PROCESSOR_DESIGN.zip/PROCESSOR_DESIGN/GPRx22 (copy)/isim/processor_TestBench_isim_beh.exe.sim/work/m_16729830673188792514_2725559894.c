/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/gaurav/IIT_KGP_COURSES/5th_Sem/COA_Lab/PROCESSOR_DESIGN/ALU/alu.v";
static const char *ng1 = "***ALU***";
static int ng2[] = {1, 0};
static unsigned int ng3[] = {17U, 0U};
static unsigned int ng4[] = {3U, 0U};
static unsigned int ng5[] = {18U, 0U};
static unsigned int ng6[] = {4U, 0U};
static unsigned int ng7[] = {19U, 0U};
static unsigned int ng8[] = {20U, 0U};
static unsigned int ng9[] = {21U, 0U};
static unsigned int ng10[] = {25U, 0U};
static unsigned int ng11[] = {26U, 0U};
static unsigned int ng12[] = {27U, 0U};
static unsigned int ng13[] = {28U, 0U};
static unsigned int ng14[] = {29U, 0U};
static unsigned int ng15[] = {30U, 0U};
static unsigned int ng16[] = {7U, 0U};
static int ng17[] = {0, 0};
static unsigned int ng18[] = {8U, 0U};
static unsigned int ng19[] = {9U, 0U};
static unsigned int ng20[] = {10U, 0U};
static unsigned int ng21[] = {11U, 0U};
static unsigned int ng22[] = {12U, 0U};
static unsigned int ng23[] = {13U, 0U};
static unsigned int ng24[] = {14U, 0U};
static unsigned int ng25[] = {5U, 0U};
static unsigned int ng26[] = {6U, 0U};
static const char *ng27 = "in1=%d, in2=%d, ALUctrl=%b, flag=%b";
static const char *ng28 = "result=%d";
static const char *ng29 = "addResult=%d, xorResult=%d, sll=%d\n";



static void Cont_38_0(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 4760U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1208U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_signed_bit_and(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 5936);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t10 = (t0 + 5824);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_39_1(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 5008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1208U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_signed_bit_xor(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 6000);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t10 = (t0 + 5840);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Always_46_2(char *t0)
{
    char t12[8];
    char t13[8];
    char t14[8];
    char *t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t10;
    int t11;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned int t28;

LAB0:    t1 = (t0 + 5256U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 5856);
    *((int *)t2) = 1;
    t3 = (t0 + 5288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(47, ng0);

LAB5:    xsi_set_current_line(48, ng0);
    xsi_vlogfile_write(1, 0, 0, ng1, 1, t0);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t4 = *((unsigned int *)t2);
    t5 = (~(t4));
    t6 = *((unsigned int *)t3);
    t7 = (t6 & t5);
    t8 = (t7 != 0);
    if (t8 > 0)
        goto LAB6;

LAB7:
LAB8:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);

LAB9:    t2 = ((char*)((ng3)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng4)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng5)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng6)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng7)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng8)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB20;

LAB21:    t2 = ((char*)((ng9)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB22;

LAB23:    t2 = ((char*)((ng10)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB24;

LAB25:    t2 = ((char*)((ng11)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB26;

LAB27:    t2 = ((char*)((ng12)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB28;

LAB29:    t2 = ((char*)((ng13)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB30;

LAB31:    t2 = ((char*)((ng14)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB32;

LAB33:    t2 = ((char*)((ng15)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB34;

LAB35:    t2 = ((char*)((ng16)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB36;

LAB37:    t2 = ((char*)((ng18)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB38;

LAB39:    t2 = ((char*)((ng19)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB40;

LAB41:    t2 = ((char*)((ng20)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB42;

LAB43:    t2 = ((char*)((ng21)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB44;

LAB45:    t2 = ((char*)((ng22)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB46;

LAB47:    t2 = ((char*)((ng23)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB48;

LAB49:    t2 = ((char*)((ng24)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB50;

LAB51:    t2 = ((char*)((ng25)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB52;

LAB53:    t2 = ((char*)((ng26)));
    t11 = xsi_vlog_unsigned_case_compare(t3, 5, t2, 5);
    if (t11 == 1)
        goto LAB54;

LAB55:
LAB57:
LAB56:    xsi_set_current_line(77, ng0);
    t2 = ((char*)((ng17)));
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t2, 0, 0, 32);

LAB58:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 1048U);
    t9 = *((char **)t2);
    t2 = (t0 + 1208U);
    t10 = *((char **)t2);
    t2 = (t0 + 1528U);
    t15 = *((char **)t2);
    t2 = (t0 + 3688);
    t16 = (t2 + 56U);
    t17 = *((char **)t16);
    xsi_vlogfile_write(1, 0, 0, ng27, 5, t0, (char)119, t9, 32, (char)119, t10, 32, (char)118, t15, 5, (char)118, t17, 1);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 3528);
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng28, 2, t0, (char)118, t10, 32);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 1848U);
    t9 = *((char **)t2);
    t2 = (t0 + 2328U);
    t10 = *((char **)t2);
    t2 = (t0 + 2488U);
    t15 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng29, 4, t0, (char)118, t9, 32, (char)118, t10, 32, (char)118, t15, 32);
    goto LAB2;

LAB6:    xsi_set_current_line(50, ng0);
    t9 = ((char*)((ng2)));
    t10 = (t0 + 3848);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 1);
    goto LAB8;

LAB10:    xsi_set_current_line(54, ng0);
    t9 = (t0 + 1848U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB12:    xsi_set_current_line(55, ng0);
    t9 = (t0 + 1848U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB14:    xsi_set_current_line(56, ng0);
    t9 = (t0 + 2008U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB16:    xsi_set_current_line(57, ng0);
    t9 = (t0 + 2008U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB18:    xsi_set_current_line(58, ng0);
    t9 = (t0 + 2168U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB20:    xsi_set_current_line(59, ng0);
    t9 = (t0 + 2328U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB22:    xsi_set_current_line(60, ng0);
    t9 = (t0 + 2968U);
    t10 = *((char **)t9);
    memcpy(t12, t10, 8);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t12, 0, 0, 32);
    goto LAB58;

LAB24:    xsi_set_current_line(61, ng0);
    t9 = (t0 + 2488U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB26:    xsi_set_current_line(62, ng0);
    t9 = (t0 + 2648U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB28:    xsi_set_current_line(63, ng0);
    t9 = (t0 + 2808U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB30:    xsi_set_current_line(64, ng0);
    t9 = (t0 + 2488U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB32:    xsi_set_current_line(65, ng0);
    t9 = (t0 + 2648U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB34:    xsi_set_current_line(66, ng0);
    t9 = (t0 + 2808U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB36:    xsi_set_current_line(67, ng0);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    t9 = ((char*)((ng17)));
    memset(t14, 0, 8);
    xsi_vlog_signed_less(t14, 32, t10, 32, t9, 32);
    memset(t13, 0, 8);
    t15 = (t14 + 4);
    t4 = *((unsigned int *)t15);
    t5 = (~(t4));
    t6 = *((unsigned int *)t14);
    t7 = (t6 & t5);
    t8 = (t7 & 1U);
    if (t8 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t15) != 0)
        goto LAB61;

LAB62:    t17 = (t13 + 4);
    t18 = *((unsigned int *)t13);
    t19 = *((unsigned int *)t17);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB63;

LAB64:    t22 = *((unsigned int *)t13);
    t23 = (~(t22));
    t24 = *((unsigned int *)t17);
    t25 = (t23 || t24);
    if (t25 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t17) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t13) > 0)
        goto LAB69;

LAB70:    memcpy(t12, t26, 8);

LAB71:    t27 = (t0 + 3688);
    xsi_vlogvar_assign_value(t27, t12, 0, 0, 1);
    goto LAB58;

LAB38:    xsi_set_current_line(68, ng0);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    t9 = ((char*)((ng17)));
    memset(t14, 0, 8);
    xsi_vlog_signed_equal(t14, 32, t10, 32, t9, 32);
    memset(t13, 0, 8);
    t15 = (t14 + 4);
    t4 = *((unsigned int *)t15);
    t5 = (~(t4));
    t6 = *((unsigned int *)t14);
    t7 = (t6 & t5);
    t8 = (t7 & 1U);
    if (t8 != 0)
        goto LAB72;

LAB73:    if (*((unsigned int *)t15) != 0)
        goto LAB74;

LAB75:    t17 = (t13 + 4);
    t18 = *((unsigned int *)t13);
    t19 = *((unsigned int *)t17);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB76;

LAB77:    t22 = *((unsigned int *)t13);
    t23 = (~(t22));
    t24 = *((unsigned int *)t17);
    t25 = (t23 || t24);
    if (t25 > 0)
        goto LAB78;

LAB79:    if (*((unsigned int *)t17) > 0)
        goto LAB80;

LAB81:    if (*((unsigned int *)t13) > 0)
        goto LAB82;

LAB83:    memcpy(t12, t26, 8);

LAB84:    t27 = (t0 + 3688);
    xsi_vlogvar_assign_value(t27, t12, 0, 0, 1);
    goto LAB58;

LAB40:    xsi_set_current_line(69, ng0);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    t9 = ((char*)((ng17)));
    memset(t14, 0, 8);
    xsi_vlog_signed_not_equal(t14, 32, t10, 32, t9, 32);
    memset(t13, 0, 8);
    t15 = (t14 + 4);
    t4 = *((unsigned int *)t15);
    t5 = (~(t4));
    t6 = *((unsigned int *)t14);
    t7 = (t6 & t5);
    t8 = (t7 & 1U);
    if (t8 != 0)
        goto LAB85;

LAB86:    if (*((unsigned int *)t15) != 0)
        goto LAB87;

LAB88:    t17 = (t13 + 4);
    t18 = *((unsigned int *)t13);
    t19 = *((unsigned int *)t17);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB89;

LAB90:    t22 = *((unsigned int *)t13);
    t23 = (~(t22));
    t24 = *((unsigned int *)t17);
    t25 = (t23 || t24);
    if (t25 > 0)
        goto LAB91;

LAB92:    if (*((unsigned int *)t17) > 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t13) > 0)
        goto LAB95;

LAB96:    memcpy(t12, t26, 8);

LAB97:    t27 = (t0 + 3688);
    xsi_vlogvar_assign_value(t27, t12, 0, 0, 1);
    goto LAB58;

LAB42:    xsi_set_current_line(70, ng0);
    t9 = ((char*)((ng2)));
    t10 = (t0 + 3688);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 1);
    goto LAB58;

LAB44:    xsi_set_current_line(71, ng0);
    t9 = ((char*)((ng2)));
    t10 = (t0 + 3688);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 1);
    goto LAB58;

LAB46:    xsi_set_current_line(72, ng0);
    t9 = ((char*)((ng2)));
    t10 = (t0 + 3688);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 1);
    goto LAB58;

LAB48:    xsi_set_current_line(73, ng0);
    t9 = (t0 + 3848);
    t10 = (t9 + 56U);
    t15 = *((char **)t10);
    t16 = (t0 + 3688);
    xsi_vlogvar_assign_value(t16, t15, 0, 0, 1);
    goto LAB58;

LAB50:    xsi_set_current_line(74, ng0);
    t9 = (t0 + 3848);
    t10 = (t9 + 56U);
    t15 = *((char **)t10);
    memset(t12, 0, 8);
    t16 = (t15 + 4);
    t4 = *((unsigned int *)t16);
    t5 = (~(t4));
    t6 = *((unsigned int *)t15);
    t7 = (t6 & t5);
    t8 = (t7 & 1U);
    if (t8 != 0)
        goto LAB101;

LAB99:    if (*((unsigned int *)t16) == 0)
        goto LAB98;

LAB100:    t17 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t17) = 1;

LAB101:    t21 = (t12 + 4);
    t26 = (t15 + 4);
    t18 = *((unsigned int *)t15);
    t19 = (~(t18));
    *((unsigned int *)t12) = t19;
    *((unsigned int *)t21) = 0;
    if (*((unsigned int *)t26) != 0)
        goto LAB103;

LAB102:    t25 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t25 & 1U);
    t28 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t28 & 1U);
    t27 = (t0 + 3688);
    xsi_vlogvar_assign_value(t27, t12, 0, 0, 1);
    goto LAB58;

LAB52:    xsi_set_current_line(75, ng0);
    t9 = (t0 + 1848U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB54:    xsi_set_current_line(76, ng0);
    t9 = (t0 + 1848U);
    t10 = *((char **)t9);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t10, 0, 0, 32);
    goto LAB58;

LAB59:    *((unsigned int *)t13) = 1;
    goto LAB62;

LAB61:    t16 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB62;

LAB63:    t21 = ((char*)((ng2)));
    goto LAB64;

LAB65:    t26 = ((char*)((ng17)));
    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t12, 32, t21, 32, t26, 32);
    goto LAB71;

LAB69:    memcpy(t12, t21, 8);
    goto LAB71;

LAB72:    *((unsigned int *)t13) = 1;
    goto LAB75;

LAB74:    t16 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB75;

LAB76:    t21 = ((char*)((ng2)));
    goto LAB77;

LAB78:    t26 = ((char*)((ng17)));
    goto LAB79;

LAB80:    xsi_vlog_unsigned_bit_combine(t12, 32, t21, 32, t26, 32);
    goto LAB84;

LAB82:    memcpy(t12, t21, 8);
    goto LAB84;

LAB85:    *((unsigned int *)t13) = 1;
    goto LAB88;

LAB87:    t16 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB88;

LAB89:    t21 = ((char*)((ng2)));
    goto LAB90;

LAB91:    t26 = ((char*)((ng17)));
    goto LAB92;

LAB93:    xsi_vlog_unsigned_bit_combine(t12, 32, t21, 32, t26, 32);
    goto LAB97;

LAB95:    memcpy(t12, t21, 8);
    goto LAB97;

LAB98:    *((unsigned int *)t12) = 1;
    goto LAB101;

LAB103:    t20 = *((unsigned int *)t12);
    t22 = *((unsigned int *)t26);
    *((unsigned int *)t12) = (t20 | t22);
    t23 = *((unsigned int *)t21);
    t24 = *((unsigned int *)t26);
    *((unsigned int *)t21) = (t23 | t24);
    goto LAB102;

}

static void implSig1_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 5504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng17)));
    t3 = (t0 + 6064);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t2, 8);
    xsi_driver_vfirst_trans(t3, 0, 31);

LAB1:    return;
}


extern void work_m_16729830673188792514_2725559894_init()
{
	static char *pe[] = {(void *)Cont_38_0,(void *)Cont_39_1,(void *)Always_46_2,(void *)implSig1_execute};
	xsi_register_didat("work_m_16729830673188792514_2725559894", "isim/processor_TestBench_isim_beh.exe.sim/work/m_16729830673188792514_2725559894.didat");
	xsi_register_executes(pe);
}
